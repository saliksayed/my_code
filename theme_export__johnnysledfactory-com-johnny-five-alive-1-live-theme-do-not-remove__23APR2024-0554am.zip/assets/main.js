jQuery(document).ready(function () {
  // Initialize the first slider
  // Define an array containing configurations for each slider
  var sliderConfigs = [
    {
      selector: "#shop-by-business-section-slider",
      autoplaySpeed: 700,
      autoplay: true,
      arrows: true,
      infinite: true,
      speed: 500,
      slidesToShow: 4,
      slidesToScroll: 1,
      
      prevArrow: ".shop_arrrow .right_arrow1",
      nextArrow: ".shop_arrrow .left_arrow1",
      responsive: [
        {
          breakpoint: 991,
          settings: {
            slidesToShow: 3,
          },
        },
        {
          breakpoint: 767,
          settings: {
            slidesToShow: 2,
            dots: true,
          },
        },  {
          breakpoint: 520,
          settings: {
            slidesToShow: 1,
            dots: true,
          },
        }
      ],
    },
    {
      selector: ".best",
      autoplay: true,
      autoplaySpeed: 700,
      arrows: true,
      infinite: true,
      speed: 500,
      slidesToShow: 3,
      slidesToScroll: 1,
      prevArrow: "#shop_arrrow_bst .right_arrow-best",
      nextArrow: "#shop_arrrow_bst .left_arrow-best",
      responsive: [
        {
          breakpoint: 991,
          settings: {
            slidesToShow: 2,
          },
        },
        {
          breakpoint: 767,
          settings: {
            slidesToShow: 1,
            dots: true,
          },
        },
      ],
    },   

   {
      selector: ".best-trending",
      autoplay: true,
      autoplaySpeed: 700,
      arrows: true,
      infinite: true,
      speed: 500,
      slidesToShow: 3,
      slidesToScroll: 1,
      prevArrow: "#shop_arrrow_bst .right_arrow-trending",
      nextArrow: "#shop_arrrow_bst .left_arrow-trending",
      responsive: [
        {
          breakpoint: 991,
          settings: {
            slidesToShow: 2,
          },
        },
        {
          breakpoint: 767,
          settings: {
            slidesToShow: 1,
            dots: true,
          },
        },
      ],
    }, 

    
      {
      selector: ".best-today-collection",
      autoplay: true,
      autoplaySpeed: 700,
      arrows: true,
      infinite: true,
      speed: 500,
      slidesToShow: 3,
      slidesToScroll: 1,
      prevArrow: "#shop_arrrow_bst .right_arrow",
      nextArrow: "#shop_arrrow_bst .left_arrow",
      responsive: [
        {
          breakpoint: 991,
          settings: {
            slidesToShow: 2,
          },
        },
        {
          breakpoint: 767,
          settings: {
            slidesToShow: 1,
            dots: true,
          },
        },
      ],
    },
    {
      selector: ".logos-slide",
      autoplay: true,
      autoplaySpeed: 700,
      arrows: true,
      infinite: true,
      speed: 500,
      slidesToShow: 5,
      slidesToScroll: 1,
      prevArrow: "#shop_arrrow_bst_seller .right_arrow",
      nextArrow: "#shop_arrrow_bst_seller .left_arrow",
      responsive: [
        {
          breakpoint: 991,
          settings: {
            slidesToShow: 2,
          },
        },
        {
          breakpoint: 767,
          settings: {
            slidesToShow: 1,
            dots: true,
          },
        },
      ],
    },
      {
      selector: ".slick-slider-create",
      slidesToShow: 3,
      slidesToScroll: 1,
      autoplay: true,  
      autoplaySpeed: 500,
      responsive: [
        {
          breakpoint: 768, // Medium devices (tablets, 768px and up)
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1
            // Add other settings for medium devices
          }
        },
        {
          breakpoint: 576, // Small devices (landscape phones, 576px and up)
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
            // Add other settings for small devices
          }
        }
      ]
    }, 
  ];
  // Loop through the sliderConfigs array to initialize each slider
  initializeSliders(sliderConfigs);

 $(document).ready(function () {
     // Show the content of the first card by default
    var defaultTitle = $(".testimonial-list .card.active").data("title");
    var defaultContent = $(".testimonial-list .card.active").data("content");
    $(".p-3.testimonials-margin h4").text(defaultTitle);
    $(".p-3.testimonials-margin p").text(defaultContent);

    // Event handler for card click
    $(".card.p-3").click(function (event) {
      event.preventDefault();
      // Remove "active" class from all cards
      $(".testimonial-list .card.p-3").removeClass("active");
      // Add "active" class to the clicked card
      $(this).addClass("active");

      var title = $(this).data("title");
      var content = $(this).data("content");
      console.log(title);
      console.log(content);
      $(".p-3.testimonials-margin h4").text(title);
      $(".p-3.testimonials-margin p").text(content);
    });
  });
  
  // vedio_functionalty
  jQuery(document).on("click", "#vedio_functionalty", async function () {
    let type = jQuery(this).attr("type");
    let Pop_up_vedio = jQuery("#Pop_up_vedio")[0]; // Get the DOM element from jQuery object
    type == "opened"
      ? (Pop_up_vedio.play(), jQuery("#popup").css("display", "block"))
      : (Pop_up_vedio.pause(), jQuery("#popup").css("display", "none"));
  });
      $(".Product_Span_Description p:not(:first-child)").hide(); // Hide all paragraphs except the first one

$(".view-more-btn").click(function(e) {
  
    e.preventDefault();
    $(this).siblings("p:not(:first-child)").toggle(); // Toggle visibility of paragraphs except the first one
    var text = $(this).text();
    $(this).text(text == "View more" ? "View less" : "View more"); // Toggle link text
});

  jQuery(document).on("click", "#Free_Quote",  function () {
                jQuery('html, body').animate({
                scrollTop: jQuery('.Custom_Neon_page_form').offset().top
            }, 500); // You can adjust the animation speed (1000ms = 1 second)

    });

  jQuery('#form_phone-number').attr('maxlength', '11');
    jQuery('#text-202441595011').attr('maxlength', '11');
    jQuery(document).on("keyup", "#form_phone-number", async function () {
        if (/\D/g.test(this.value)) {
            // Filter non-digits from input value.
            this.value = this.value.replace(/\D/g, '');
        }
    });
});

