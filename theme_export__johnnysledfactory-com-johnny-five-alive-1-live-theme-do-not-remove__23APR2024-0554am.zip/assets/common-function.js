const initializeSliders = (sliderConfigs) => {
  sliderConfigs.forEach(function (sliderConfig) {
    $(sliderConfig.selector).slick({
      autoplaySpeed: sliderConfig.autoplaySpeed,
      autoplay: sliderConfig.autoplay,
      arrows: sliderConfig.arrows,
      infinite: sliderConfig.infinite,
      speed: sliderConfig.speed,
      slidesToShow: sliderConfig.slidesToShow,
      slidesToScroll: sliderConfig.slidesToScroll,
      prevArrow: $(sliderConfig.prevArrow),
      nextArrow: $(sliderConfig.nextArrow),
      responsive: sliderConfig.responsive,
    });
  });
};
const getWords = (str) => {
      return str.split(/\s+/).slice(0,12).join(" ");
}