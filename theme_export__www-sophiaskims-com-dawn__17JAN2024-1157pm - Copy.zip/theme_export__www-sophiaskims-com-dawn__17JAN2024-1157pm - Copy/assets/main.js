$(document).ready(function(){
  var change_colors = jQuery('.color_get_0 input').val();
  jQuery('span.color_names_0').text( change_colors );
  var change_size = jQuery('.color_get_1 input').val();
  jQuery('span.color_names_1').text( change_size );
  
  $('label.mineTitle_Color').click(function(){
    var getColor = $(this).attr('valuemine');
    $('.color_names_0').html(getColor);
  });

  $('label.mineTitle_Size').click(function(){
    var getColor = $(this).attr('valuemine');
    $('.color_names_1').html(getColor);
  });

    $(".slider_testimonial_sec").slick({
    dots: false,
    infinite: false,
    speed: 300,
    slidesToShow: 3,
    slidesToScroll: 1,
    infinite: true,
    prevArrow: $(".slide_controls_1 .slide-prev"),
    nextArrow: $(".slide_controls_1 .slide-next"),
                 responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
  ]
  });
  $('.home-slider').slick({
infinite: true,
  arrows: true,
  dots: false,
  prevArrow:"<img class='a-left control-c prev slick-prev' src='https://cdn.shopify.com/s/files/1/0844/4143/2360/files/right_arrow.png?v=1701692816'>",
  nextArrow:"<img class='a-right control-c next slick-next' src='https://cdn.shopify.com/s/files/1/0844/4143/2360/files/left_arrow.png?v=1701692816'>"
  });
  // $('.testimonial_slider').slick({
  //     infinite: true,
  //     arrows: false,
  //     dots: false,
  // });

  $(".testimonial_slide-txt").slick({
  dots: true,
  infinite: false,
  speed: 300,
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: true,
  prevArrow: $(".slide_controls_1 .slide-prev"),
  nextArrow: $(".slide_controls_1 .slide-next"),
         
});
  

  var change_colors = jQuery('.color_get input').val();
    jQuery('span.color_names').text( change_colors );
jQuery('.color_get input').click(function(){
    var change_colors = jQuery(this).val();
    jQuery('span.color_names').text( change_colors );
})

      // Select the container containing the labels
      var container = $('.card__information');

      // Create an empty array to store unique values
      var uniqueValues = [];

      // Iterate over each label within the container
      container.find('label').each(function() {
        // Get the text content of the label
        var labelText = $(this).text().trim();

        // Check if the value is not in the uniqueValues array
        if (uniqueValues.indexOf(labelText) === -1) {
          // Add the value to the uniqueValues array
          uniqueValues.push(labelText);
        } else {
          // Remove the duplicate label
          $(this).remove();
        }
      });


$("#hide").click(function(){
  $("p").hide();
});

$(".c_value").click(function(){
  $("p").show();
});



    
});

$('.multiple-items').slick({
  infinite: true,



});



